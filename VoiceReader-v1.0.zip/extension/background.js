// background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "open_panel") {
      chrome.windows.create({
        url: chrome.runtime.getURL("popup.html"),
        type: "popup",
        width: 400,
        height: 600,
        left: 100,
        top: 100
      });
    } else if (request.action === "get_selected_text") {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          function: getSelectedText
        }, (results) => {
          sendResponse({selectedText: results[0].result || ""});
        });
      });
      return true; // Keep the message channel open for the async response
    }
  });
  
  function getSelectedText() {
    return window.getSelection().toString();
  }
  